% Author and Developer: Dr. Taymaz Rahkar Farshi
% Color image quantization with peak-picking and color space
% https://doi.org/10.1007/s00530-020-00682-5
%  Journal of Multimedia Systems
% taymaz.farshi@gmail.com
% Istanbul 2020
% www.taymaz.dev
function [peaks] = peaks2vec(Pr,Pg,Pb)

c={Pr,Pg,Pb};
[c{:}]=ndgrid(c{:});
n=length(c);
peaks = reshape(cat(n+1,c{:}),[],n);


end

